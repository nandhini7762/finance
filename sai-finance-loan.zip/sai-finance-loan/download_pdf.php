<?php
require('fpdf.php'); // Include the FPDF library

// Include the database connection
include 'db.php';

// Check if 'id' is passed in the URL
if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Fetch the payment details using the 'id'
    $payment_query = "SELECT * FROM payments WHERE id = ?";
    $stmt = $conn->prepare($payment_query);
    $stmt->bind_param("i", $payment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $payment = $result->fetch_assoc();

    if (!$payment) {
        die("Payment not found.");
    }
} else {
    echo "Payment ID not specified.";
    exit;
}

// Create a PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Add logo at the top center
$pdf->Image('logooo.jpg', 80, 10, 50); // Adjust x, y, and width (50) as per your requirement

// Increase the gap below the image for better spacing
$pdf->Ln(40); // Adjust the value (50) to increase or decrease the gap as needed

// Set title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, 'Payment Receipt', 0, 1, 'C');

// Set font for table (without borders)
$pdf->SetFont('Arial', '', 12);

// Add table header without borders
$pdf->Cell(95, 10, 'Customer Name:', 0);
$pdf->Cell(95, 10, $payment['customer_name'], 0, 1);

// Add table rows without borders
$pdf->Cell(95, 10, 'Paid Amount:', 0);
$pdf->Cell(95, 10, number_format($payment['amount_paid'], 2), 0, 1);

$pdf->Cell(95, 10, 'Paid Date:', 0);
$pdf->Cell(95, 10, $payment['paid_date'], 0, 1);

$pdf->Cell(95, 10, 'Total Loan Amount:', 0);
$pdf->Cell(95, 10, number_format($payment['total_loan_amount'], 2), 0, 1);

$pdf->Cell(95, 10, 'Mode of Payment:', 0);
$pdf->Cell(95, 10, $payment['mode_of_payment'], 0, 1);

// Set the file name for the PDF
$customer_name = str_replace(' ', '_', $payment['customer_name']); // Replace spaces with underscores for the filename
$paid_amount = number_format($payment['amount_paid'], 2);
$pdf_filename = "{$paid_amount}_{$customer_name}.pdf"; // The format: amountpaid_customername.pdf

// Output the PDF and force download with the dynamic filename
$pdf->Output('D', $pdf_filename); // Force download with the custom filename
exit;
?>
