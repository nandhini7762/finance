-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2025 at 12:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sai_finance`
--

-- --------------------------------------------------------

--
-- Table structure for table `backup_customers`
--

CREATE TABLE `backup_customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `loan_apply_date` date DEFAULT NULL,
  `loan_amount` decimal(10,2) DEFAULT NULL,
  `interest_rate` decimal(5,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `no_of_months` int(11) DEFAULT NULL,
  `due_per_month` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `alt_number` varchar(15) DEFAULT NULL,
  `loan_apply_date` date NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `status` enum('Approved','Rejected','Pending') DEFAULT 'Pending',
  `confirmation_date` date DEFAULT NULL,
  `no_of_months` int(22) NOT NULL,
  `due_per_month` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `address`, `phone_number`, `alt_number`, `loan_apply_date`, `loan_amount`, `interest_rate`, `status`, `confirmation_date`, `no_of_months`, `due_per_month`) VALUES
(19, 'sheela', 'uthukuli main road karumarampalayam,Tirupur 641 607', '6369446212', NULL, '2024-12-31', 400000.00, 2.00, 'Rejected', '2024-12-31', 0, 8000.00),
(20, 'nandhini senthilkumar', 'tiruppur', '9898989898', NULL, '2025-01-03', 100000.00, 1.00, 'Approved', '2025-01-05', 2, 166.00),
(21, 'Nandhini S', 'uthukuli main road karumarampalayam,Tirupur 641 607', '8072946167', '', '2025-01-11', 400000.00, 2.00, 'Approved', '2025-01-11', 10, 46667.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `paid_date` date NOT NULL,
  `total_loan_amount` decimal(10,2) NOT NULL,
  `mode_of_payment` enum('Cash','Card','Online','Cheque') NOT NULL,
  `no_of_due` int(11) NOT NULL,
  `dues_paid` int(11) NOT NULL,
  `remaining_due` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone_number` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `customer_name`, `amount_paid`, `paid_date`, `total_loan_amount`, `mode_of_payment`, `no_of_due`, `dues_paid`, `remaining_due`, `created_at`, `phone_number`) VALUES
(1, 'Nandhini', 666.00, '2025-01-09', 4444444.00, 'Cash', 4, 45, 5, '2025-01-03 14:22:19', NULL),
(2, 'nandhini', 30000.00, '2025-01-11', 66666660.00, 'Card', 12, 2, 2, '2025-01-11 08:22:53', '9843042050'),
(3, 'Nandhini S', 46667.00, '2025-01-11', 400000.00, 'Cash', 10, 1, 9, '2025-01-11 09:05:37', '8072946167'),
(4, 'Nandhini S', 46667.00, '2025-01-11', 400000.00, 'Card', 10, 1, 9, '2025-01-11 11:50:30', '8072946167');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `backup_customers`
--
ALTER TABLE `backup_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
