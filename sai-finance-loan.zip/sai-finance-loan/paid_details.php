<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php'; // Include the database connection

$search = '';
if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
}

$payments_query = "SELECT * FROM payments WHERE customer_name LIKE '%$search%' ORDER BY paid_date DESC";
$payments_result = $conn->query($payments_query);

if (!$payments_result) {
    die("Error fetching payments: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paid Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f1f1f1;
        }
        a, button {
            color: #007BFF;
            text-decoration: none;
            padding: 6px 12px;
            margin: 0 4px;
            border: none;
            background-color: transparent;
            cursor: pointer;
        }
        a:hover, button:hover {
            text-decoration: underline;
        }
        button {
            background-color: #28a745;
            color: white;
            border-radius: 4px;
        }
        button:hover {
            background-color: #218838;
        }
        .add-customer-button, .home-button, .search-box {
            display: inline-block;
            margin: 10px;
        }
        .add-customer-button, .home-button {
            padding: 12px 20px;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            text-align: center;
            font-size: 1rem;
            text-decoration: none;
        }
        .add-customer-button:hover, .home-button:hover {
            background-color: #0056b3;
        }
        .search-box input {
            padding: 8px;
            width: 300px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .search-box button {
            padding: 8px 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .search-box button:hover {
            background-color: #0056b3;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            table {
                width: 90%;
            }
            .search-box input {
                width: 250px;
            }
            .add-customer-button, .home-button {
                padding: 10px 18px;
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .search-box input {
                width: 200px;
            }
            .search-box button {
                padding: 6px 10px;
            }
            table, th, td {
                padding: 10px;
            }
            .add-customer-button, .home-button {
                padding: 10px 16px;
                font-size: 0.8rem;
            }
            h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div style="text-align: center;">
        <a href="home.php" class="home-button">Home</a>
        <a href="payments.php" class="add-customer-button">Add Payments</a>
        <div class="search-box" style="display: inline-block;">
            <form method="POST" action="">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search for a customer..." />
                <button type="submit">Search</button>
            </form>
        </div>
    </div>

    <h2>Payment Details</h2>
    <table>
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Total Loan Amount</th>
                <th>Paid Due Amount</th>
                <th>Paid Date</th>
                <th>Mode of Payment</th>
                <th>Number of Dues</th>
                <th>Dues Paid</th>
                <th>Remaining Dues</th>
                <th>Action</th>

            </tr>
        </thead>
        <tbody>
            <?php 
            if ($payments_result->num_rows > 0) {
                while ($row = $payments_result->fetch_assoc()) {
                    $payment_id = $row['id'];
                    echo "<tr>
                            <td>" . htmlspecialchars($row['customer_name']) . "</td>
                            <td>" . number_format($row['total_loan_amount'], 2) . "</td>
                            <td>" . number_format($row['amount_paid'], 2) . "</td>
                            <td>" . htmlspecialchars($row['paid_date']) . "</td>
                            
                            <td>" . htmlspecialchars($row['mode_of_payment']) . "</td>
                            <td>" . htmlspecialchars($row['no_of_due']) . "</td>
                            <td>" . htmlspecialchars($row['dues_paid']) . "</td>
                            <td>" . htmlspecialchars($row['remaining_due']) . "</td>
                            <td>
                                <a href='view_payment.php?id=" . $payment_id . "'>
                                    <i class='fas fa-file-pdf' style='font-size: 20px; color: #e74c3c;'></i>
                                </a>
                                <a href='update_payment.php?id=" . $payment_id . "'>
                                    <i class='fas fa-edit' style='font-size: 20px; color: #007bff;'></i>
                                </a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No payment details available.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
