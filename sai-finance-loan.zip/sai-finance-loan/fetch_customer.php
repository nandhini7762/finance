<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $phone_number = $conn->real_escape_string($data['phone_number']);

    $query = "SELECT full_name AS customer_name, loan_amount AS total_loan_amount, no_of_months AS no_of_due, due_per_month FROM customers WHERE phone_number = '$phone_number'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $customer = $result->fetch_assoc();
        echo json_encode([
            'success' => true, 
            'customer_name' => $customer['customer_name'], 
            'total_loan_amount' => $customer['total_loan_amount'], 
            'no_of_due' => $customer['no_of_due'],
            'due_per_month' => $customer['due_per_month']
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
}
