<?php 
include 'db.php'; // Include database connection  
$message = '';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {     
    // Round the values before inserting
    $customer_name = $conn->real_escape_string($_POST['name']);     
    $phone_number = $conn->real_escape_string($_POST['phone_number']);     
    $amount_paid = round($conn->real_escape_string($_POST['amount_paid']));     
    $paid_date = $conn->real_escape_string($_POST['paid_date']);     
    $total_loan_amount = round($conn->real_escape_string($_POST['total_loan_amount']));     
    $mode_of_payment = $conn->real_escape_string($_POST['mode_of_payment']);     
    $no_of_due = $conn->real_escape_string($_POST['no_of_due']);     
    $dues_paid = round($conn->real_escape_string($_POST['dues_paid']));     
    $remaining_due = round($conn->real_escape_string($_POST['remaining_due']));      

    // Insert the payment into the database     
    $query = "INSERT INTO payments (customer_name, phone_number, amount_paid, paid_date, total_loan_amount, mode_of_payment, no_of_due, dues_paid, remaining_due)               
              VALUES ('$customer_name', '$phone_number', '$amount_paid', '$paid_date', '$total_loan_amount', '$mode_of_payment', '$no_of_due', '$dues_paid', '$remaining_due')";      

    if ($conn->query($query) === TRUE) {         
        $payment_id = $conn->insert_id;         
        $message = "Payment added successfully.";         
        header('Location: view_payment.php?id=' . $payment_id);         
        exit();     
    } else {         
        $message = "Error: " . $conn->error;     
    } 
}

// Fetch customer data for the phone number if set
$due_per_month = '';
if (isset($_GET['phone_number']) && !empty($_GET['phone_number'])) {
    $phone_number = $conn->real_escape_string($_GET['phone_number']);
    $query = "SELECT due_per_month FROM customers WHERE phone_number = '$phone_number'";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $customer = $result->fetch_assoc();
        $due_per_month = round($customer['due_per_month']); // Round the value here to remove decimals
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            font-size: 36px;
            color: #333;
        }

        .form-container {
            width: 90%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        form input, form button {
            display: block;
            width: 100%;
            margin: 10px 0;
            padding: 12px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
        }

        form button {
            background-color: #007BFF;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border: none;
        }

        form button:hover {
            background-color: #0056b3;
        }

        form .cancel-button {
            background-color: #dc3545;
            color: white;
        }

        form .cancel-button:hover {
            background-color: #c82333;
        }

        .form-container h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        form .mode-label {
            font-weight: bold;
            margin-top: 10px;
            font-size: 14px;
            display: block;
        }
        form input[type="radio"] {
            display: inline-block;
            width: auto;
            margin-right: 10px;
        }

        form .radio-group label {
            display: inline-block;
            font-weight: normal;
            font-size: 14px;
            margin-right: 20px;
        }


        /* To ensure that the inputs for the dues fields are aligned nicely */
        .dues-input {
            width: 48%;
            display: inline-block;
        }

        .dues-input:last-child {
            margin-left: 4%;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelector('[name="phone_number"]').addEventListener('input', fetchCustomerDetails);

            function fetchCustomerDetails(e) {
                const phoneNumber = e.target.value;
                if (phoneNumber.length === 10) {
                    fetch('fetch_customer.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ phone_number: phoneNumber })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.querySelector('[name="name"]').value = data.customer_name;
                            document.querySelector('[name="total_loan_amount"]').value = Math.round(data.total_loan_amount); // Round the value here
                            document.querySelector('[name="no_of_due"]').value = data.no_of_due;
                            document.querySelector('[name="due_per_month"]').value = Math.round(data.due_per_month) || ''; // Auto populate and round due_per_month
                            // Set amount_paid to be the same as due_per_month, rounded
                            document.querySelector('[name="amount_paid"]').value = Math.round(data.due_per_month) || '';
                        }
                    })
                    .catch(error => console.error('Error:', error));
                }
            }
        });
    </script>
</head>
<body>
    <h1>Add Payments</h1>
    <div class="form-container">
        <h2>Add Payment</h2>
        <?php if (!empty($message)) echo "<p>$message</p>"; ?>
        <form method="POST" action="">
            <input type="text" name="name" placeholder="Customer Name" required readonly>
            <input type="text" name="phone_number" placeholder="Phone Number" required>
            <input type="text" name="amount_paid" placeholder="Amount Paid" required>
            <input type="date" name="paid_date" required>
            <input type="text" name="total_loan_amount" placeholder="Total Loan Amount" required readonly>

            <label class="mode-label" for="mode_of_payment">Mode of Payment:</label>
            <div class="radio-group">
                <input type="radio" id="cash" name="mode_of_payment" value="Cash" required>
                <label for="cash">Cash</label>

                <input type="radio" id="card" name="mode_of_payment" value="Card">
                <label for="card">Card</label>

                <input type="radio" id="online" name="mode_of_payment" value="Online">
                <label for="online">Online (GPay, PhonePe, Paytm)</label>

                <input type="radio" id="cheque" name="mode_of_payment" value="Cheque">
                <label for="cheque">Cheque</label>
            </div>

            <div class="dues-input">
                <input type="text" name="no_of_due" placeholder="Number of Dues" required readonly>
            </div>
            <div class="dues-input">
                <input type="text" name="dues_paid" placeholder="Dues Paid" required>
            </div>

            <input type="text" name="remaining_due" placeholder="Remaining Due" required>
            <input type="text" name="due_per_month" placeholder="Due Per Month" value="<?php echo $due_per_month; ?>" readonly>

            <button type="submit">Add Payment</button>
            <button type="button" class="cancel-button" onclick="window.location.href='paid_details.php'">Cancel</button>
        </form>
    </div>
</body>
</html>
