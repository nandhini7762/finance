<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Get the customer ID from the URL
$customer_id = $_GET['id'];

// Fetch the customer details from the database
$stmt = $conn->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

$status_update = isset($_GET['status_update']) ? $_GET['status_update'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Customer Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            width: 40%;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .customer-details p {
            font-size: 1rem;
            color: #555;
            margin: 5px 0;
        }

        .status-update {
            text-align: center;
            margin-bottom: 15px;
        }

        .status-update p {
            color: green;
        }

        form {
            margin-top: 20px;
        }

        form .status-radio {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 15px;
        }

        form .status-radio label {
            font-size: 1rem;
            color: #555;
        }

        form button {
            display: block;
            margin: 0 auto;
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }

        form button:hover {
            background: #45a049;
        }

        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .action-buttons a,
        .action-buttons form button {
            text-align: center;
            text-decoration: none;
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .action-buttons a:hover,
        .action-buttons form button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h1>Customer Profile</h1>

        <?php if ($status_update == 'success'): ?>
            <div class="status-update">
                <p>Status updated successfully!</p>
            </div>
        <?php endif; ?>

        <div class="customer-details">
            <p><strong>Full Name:</strong> <?= htmlspecialchars($customer['full_name']) ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($customer['address']) ?></p>
            <p><strong>Phone Number:</strong> <?= htmlspecialchars($customer['phone_number']) ?></p>
            <p><strong>Alternative Number:</strong> <?= htmlspecialchars($customer['alt_number']) ?></p>
            <p><strong>Loan Apply Date:</strong> <?= htmlspecialchars($customer['loan_apply_date']) ?></p>
            <p><strong>Loan Amount:</strong> <?= htmlspecialchars($customer['loan_amount']) ?></p>
            <p><strong>Interest Rate:</strong> <?= htmlspecialchars($customer['interest_rate']) ?>%</p>
            <p><strong>No of Months:</strong> <?= htmlspecialchars($customer['no_of_months']) ?></p>
            <p><strong>Due Per Month:</strong> <?= htmlspecialchars($customer['due_per_month']) ?></p>
        </div>

        <form method="POST" action="update_status.php">
            <div class="status-radio">
                <label>
                    <input type="radio" name="status" value="Approved" <?= $customer['status'] == 'Approved' ? 'checked' : '' ?>> Approved
                </label>
                <label>
                    <input type="radio" name="status" value="Rejected" <?= $customer['status'] == 'Rejected' ? 'checked' : '' ?>> Rejected
                </label>
                <label>
                    <input type="radio" name="status" value="Pending" <?= $customer['status'] == 'Pending' ? 'checked' : '' ?>> Pending
                </label>
            </div>

            <input type="hidden" name="customer_id" value="<?= $customer['id'] ?>">
            <button type="submit">Update Status</button>
        </form>

        <div class="action-buttons">
            <form method="GET" action="generate_invoice.php" target="_blank">
                <input type="hidden" name="id" value="<?= $customer['id'] ?>">
                <button type="submit">Download Invoice</button>
            </form>
            <div class="action-buttons">
    <a href="home.php">Go to Home</a>
        </div>
        </div>
   
  
        </div>
</body>
</html>
