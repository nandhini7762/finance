<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Get the filter value from the query string if set, else default to "All"
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'All';

// Create the SQL query based on the selected filter
$sql = "SELECT id, full_name, status, confirmation_date FROM customers";
if ($filter == 'Approved') {
    $sql .= " WHERE status = 'Approved'";
} elseif ($filter == 'Rejected') {
    $sql .= " WHERE status = 'Rejected'";
} elseif ($filter == 'Pending') {
    $sql .= " WHERE status = 'Pending'";
}
$loan_details = $conn->query($sql);

// Check for query errors
if (!$loan_details) {
    die("Error retrieving loan details: " . $conn->error);
}

// Count the number of loans in each status
$approved = $conn->query("SELECT COUNT(*) AS count FROM customers WHERE status='Approved'")->fetch_assoc()['count'] ?? 0;
$rejected = $conn->query("SELECT COUNT(*) AS count FROM customers WHERE status='Rejected'")->fetch_assoc()['count'] ?? 0;
$pending = $conn->query("SELECT COUNT(*) AS count FROM customers WHERE status='Pending'")->fetch_assoc()['count'] ?? 0;

// Count the total number of loans
$total_loans = $conn->query("SELECT COUNT(*) AS count FROM customers")->fetch_assoc()['count'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Loan Status with Dashboard</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        .dashboard {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px 0;
        }

        .card {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            border-radius: 10px;
            width: 200px;
            text-align: center;
            font-size: 18px;
        }

        .actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px 0;
        }

        .actions a {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .actions a:hover {
            background-color: #0056b3;
        }

        #loan-status-table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #fff;
        }

        #loan-status-table th, #loan-status-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        #loan-status-table th {
            background-color: #f1f1f1;
        }

        #loan-status-table tr:hover {
            background-color: #f1f1f1;
        }

        #loan-status-table td a {
            text-decoration: none;
            color: #007BFF;
        }

        #loan-status-table td a:hover {
            text-decoration: underline;
        }

        /* Filter Dropdown Styles */
        form {
            text-align: center;
            margin-bottom: 20px;
        }

        select {
            padding: 10px 30px;
            font-size: 16px;
            border-radius: 10px;
            border: 5px solid #ccc;
            background-color: #fff;
            color: #333;
            transition: border-color 0.3s;
        }

        select:hover {
            border-color: #007BFF;
        }

        select:focus {
            border-color: #007BFF;
            outline: none;
        }

        /* Media Query for responsiveness */
        @media (max-width: 768px) {
            .dashboard {
                flex-direction: column;
                align-items: center;
            }

            .actions {
                flex-direction: column;
                align-items: center;
            }

            #loan-status-table {
                width: 95%;
            }
        }
    </style>
</head>
<body>
    

    <!-- Admin Dashboard -->
    <div class="dashboard">
        <div class="card">Approved: <?= $approved ?></div>
        <div class="card">Rejected: <?= $rejected ?></div>
        <div class="card">Pending: <?= $pending ?></div>
        <div class="card">Total Loans: <?= $total_loans ?></div>
    </div>

    <!-- Actions Links -->
    <div class="actions">
        <a href="add_customer.php">Add Customer</a>
        <a href="paid_details.php">Paid Details</a>
        <a href="home.php">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    <!-- Filter Dropdown -->
    <div style="text-align: center; margin-bottom: 20px;">
        <form action="loan_status.php" method="GET">
            <label for="filter" style="font-size: 16px; margin-right: 15px;">Filter by Status:</label>
            <select name="filter" id="filter" onchange="this.form.submit()">
                <option value="All" <?= $filter == 'All' ? 'selected' : '' ?>>All</option>
                <option value="Approved" <?= $filter == 'Approved' ? 'selected' : '' ?>>Approved</option>
                <option value="Rejected" <?= $filter == 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                <option value="Pending" <?= $filter == 'Pending' ? 'selected' : '' ?>>Pending</option>
            </select>
        </form>
    </div>

    <!-- Loan Status Table -->
    <h2>Loan Status Overview</h2>
    <table id="loan-status-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Date of Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $loan_details->fetch_assoc()) : ?>
            <tr>
                <td><?= $row['full_name'] ?></td>
                <td><?= $row['status'] ?></td>
                <td><?= $row['confirmation_date'] ?: 'N/A' ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
