<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php'; // Include the database connection

// Check if 'id' is passed in the URL
if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Fetch the payment details using the 'id'
    $payment_query = "SELECT * FROM payments WHERE id = ?";
    $stmt = $conn->prepare($payment_query);
    $stmt->bind_param("i", $payment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $payment = $result->fetch_assoc();

    if (!$payment) {
        die("Payment not found.");
    }

    // Handle form submission to update payment details
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get updated values from the form
        $customer_name = $_POST['customer_name'];
        $amount_paid = $_POST['amount_paid'];
        $paid_date = $_POST['paid_date'];
        $total_loan_amount = $_POST['total_loan_amount'];
        $mode_of_payment = $_POST['mode_of_payment'];
       
        // Update the payment details in the database
        $update_query = "UPDATE payments SET customer_name = ?, amount_paid = ?, paid_date = ?, total_loan_amount = ?, mode_of_payment = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("sdsssd", $customer_name, $amount_paid, $paid_date, $total_loan_amount, $mode_of_payment, $payment_id);
        $stmt->execute();

        echo "Payment updated successfully.";
    }
} else {
    echo "Payment ID not specified.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Payment</title>
   
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Restrict numerical fields to only allow numbers
            ['amount_paid', 'total_loan_amount'].forEach(field => {
                document.querySelector(`[name="${field}"]`).addEventListener('input', (e) => {
                    e.target.value = e.target.value.replace(/[^0-9.]/g, ''); // Allow only numbers and decimal points
                });
            });

            // Disable autocomplete for all inputs
            document.querySelectorAll('input').forEach(input => {
                input.setAttribute('autocomplete', 'off');
            });
        });
    </script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        form {
            width: 30%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="number"], input[type="date"] {
            width: 90%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .radio-group {
            margin-bottom: 20px;
        }
        .radio-group label {
            display: inline-block;
            margin-right: 15px;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            text-align: center;
        }
        button:hover {
            background-color: #218838;
        }
        .cancel-button {
            background-color: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            text-align: center;
        }
        .cancel-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h1>Update Payment Details</h1>
    <form method="POST">
        <label>Customer Name:</label>
        <input type="text" name="customer_name" value="<?php echo htmlspecialchars($payment['customer_name']); ?>" readonly>

        <label>Payment Amount:</label>
        <input type="text" name="amount_paid" value="<?php echo htmlspecialchars($payment['amount_paid']); ?>" required>

        <label>Paid Date:</label>
        <input type="date" name="paid_date" value="<?php echo htmlspecialchars($payment['paid_date']); ?>" required>

        <label>Total Loan Amount:</label>
        <input type="text" name="total_loan_amount" value="<?php echo htmlspecialchars($payment['total_loan_amount']); ?>" readonly>

        <label>Mode of Payment:</label>
        <div class="radio-group">
            <label>
                <input type="radio" name="mode_of_payment" value="Cash" <?php echo ($payment['mode_of_payment'] == 'Cash') ? 'checked' : ''; ?>> Cash
            </label>
            <label>
                <input type="radio" name="mode_of_payment" value="Card" <?php echo ($payment['mode_of_payment'] == 'Card') ? 'checked' : ''; ?>> Card
            </label>
            <label>
                <input type="radio" name="mode_of_payment" value="Online" <?php echo ($payment['mode_of_payment'] == 'Online') ? 'checked' : ''; ?>> Online
            </label>
            <label>
                <input type="radio" name="mode_of_payment" value="Cheque" <?php echo ($payment['mode_of_payment'] == 'Cheque') ? 'checked' : ''; ?>> Cheque
            </label>
        </div>

        <button type="submit">Update Payment</button>
        <a href="paid_details.php" class="cancel-button">Cancel</a>
    </form>
</body>
</html>

