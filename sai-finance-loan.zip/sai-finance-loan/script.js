function filterTable() {
    const input = document.getElementById('search-box');
    const filter = input.value.toLowerCase();
    const rows = document.querySelectorAll('#customer-table tbody tr');

    rows.forEach(row => {
        const name = row.querySelector('td').textContent.toLowerCase();
        row.style.display = name.includes(filter) ? '' : 'none';
    });
}
