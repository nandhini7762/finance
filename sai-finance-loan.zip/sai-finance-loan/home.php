<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Fetch customer data
$customers_query = "SELECT id, full_name, address, phone_number, loan_apply_date, loan_amount, interest_rate, status, confirmation_date, no_of_months, due_per_month FROM customers";
$customers = $conn->query($customers_query);

if ($customers === false) {
    die('Error executing query: ' . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        .actions {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 20px 0;
        }

        .actions a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .actions a:hover {
            background-color: #0056b3;
        }

        #search-box {
            display: block;
            margin: 20px auto;
            padding: 10px;
            width: 70%;
            max-width: 400px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        #status-filter,
        #loan-date-filter {
            display: inline-block;
            padding: 10px;
            margin-left: 10px;
            border-radius: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            background-color: white;
        }

        #refresh-btn {
            padding: 10px;
            background-color: #0056b3;
            color: white;
            border-radius: 50%;
            font-size: 18px;
            cursor: pointer;
            border: none;
        }

        #refresh-btn:hover {
            background-color: #0056b3;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 10px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f7f7f7;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        td a {
            text-decoration: none;
            color: #007BFF;
        }

        td a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="actions">
        <a href="add_customer.php">Add Customer</a>
        <a href="loan_status.php">Loan Status</a>
        <a href="paid_details.php">Paid Details</a>
        <a href="backup.php">Back up</a>
        <a href="logout.php">Logout</a>
    </div>

    <h2>All Customers</h2>

    <!-- Search and Filters -->
    <div style="text-align: center;">
        <input type="text" id="search-box" placeholder="Search customers..." onkeyup="filterTable()">
        <select id="status-filter" onchange="filterTable()">
            <option value="">All Statuses</option>
            <option value="Approved">Approved</option>
            <option value="Pending">Pending</option>
            <option value="Rejected">Rejected</option>
        </select>
        <input type="date" id="loan-date-filter" onchange="filterTable()">
        <button id="refresh-btn" onclick="resetFilters()">
            <i class="fas fa-sync-alt"></i>
        </button>
    </div>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Loan Apply Date</th>
                <th>Loan Amount</th>
                <th>Interest Rate</th>
                <th>Status</th>
                <th>Confirmation Date</th>
                <th>No of Months</th>
                <th>Due Per Month</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="customer-table">
            <?php while ($row = $customers->fetch_assoc()) : ?>
            <tr>
                <td><a href="view_customer.php?id=<?= $row['id'] ?>"><?= $row['full_name'] ?></a></td>
                <td><?= $row['address'] ?></td>
                <td><?= $row['phone_number'] ?></td>
                <td><?= $row['loan_apply_date'] ?></td>
                <td><?= $row['loan_amount'] ?></td>
                <td><?= $row['interest_rate'] ?>%</td>
                <td><?= $row['status'] ?></td>
                <td><?= $row['confirmation_date'] ?></td>
                <td><?= $row['no_of_months'] ?></td>
                <td><?= $row['due_per_month'] ?></td>
                <td>
                    <a href="delete_customer.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this customer?')">Delete</a>
                
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <script>
        function filterTable() {
            const searchInput = document.getElementById('search-box').value.toLowerCase();
            const statusFilter = document.getElementById('status-filter').value.toLowerCase();
            const loanDateFilter = document.getElementById('loan-date-filter').value;
            const rows = document.querySelectorAll('#customer-table tr');

            rows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                const statusText = row.cells[6].textContent.toLowerCase(); // Status is in the 7th column (index 6)
                const loanApplyDate = row.cells[3].textContent.trim(); // Loan Apply Date is in the 4th column (index 3)

                const matchLoanDate = loanDateFilter ? loanApplyDate.includes(loanDateFilter) : true;

                if (
                    rowText.includes(searchInput) && 
                    (statusFilter === "" || statusText.includes(statusFilter)) &&
                    matchLoanDate
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function resetFilters() {
            document.getElementById('search-box').value = '';
            document.getElementById('status-filter').value = '';
            document.getElementById('loan-date-filter').value = '';
            filterTable(); // Call the filter function to update the table display
        }
    </script>
</body>
</html>
