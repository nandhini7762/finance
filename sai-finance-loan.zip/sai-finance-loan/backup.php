<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Fetch all backed-up customer data
$backup_query = "SELECT * FROM backup_customers";
$backups = $conn->query($backup_query);

if ($backups === false) {
    die('Error executing query: ' . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup Customers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        .actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .actions button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .actions button:hover {
            background-color: #0056b3;
        }

        #search-box {
            display: inline-block;
            padding: 10px;
            width: 80%;
            max-width: 400px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 10px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f7f7f7;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
<h2>Backed-Up Customer Details</h2>

    <div class="actions">
        <button onclick="window.location.href='home.php'">Home</button>
        <input type="text" id="search-box" placeholder="Search customers..." onkeyup="filterTable()">
    </div>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone Number</th>
                <th>Loan Apply Date</th>
                <th>Loan Amount</th>
                <th>Interest Rate</th>
                <th>Status</th>
                <th>Confirmation Date</th>
                <th>No of Months</th>
                <th>Due Per Month</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="backup-table">
            <?php while ($row = $backups->fetch_assoc()) : ?>
            <tr>
                <td><?= $row['full_name'] ?></td>
                <td><?= $row['address'] ?></td>
                <td><?= $row['phone_number'] ?></td>
                <td><?= $row['loan_apply_date'] ?></td>
                <td><?= $row['loan_amount'] ?></td>
                <td><?= $row['interest_rate'] ?>%</td>
                <td><?= $row['status'] ?></td>
                <td><?= $row['confirmation_date'] ?></td>
                <td><?= $row['no_of_months'] ?></td>
                <td><?= $row['due_per_month'] ?></td>
                <td><a href="restore_backup.php?id=<?= $row['id'] ?>">Restore</a></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <script>
        function filterTable() {
            const searchInput = document.getElementById('search-box').value.toLowerCase();
            const rows = document.querySelectorAll('#backup-table tr');
            rows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                row.style.display = rowText.includes(searchInput) ? '' : 'none';
            });
        }
    </script>
</body>
</html>
