<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Check if customer ID is provided
if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];

    // Fetch the customer data that will be deleted
    $customer_query = "SELECT * FROM customers WHERE id = ?";
    $stmt = $conn->prepare($customer_query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the customer exists
    if ($result->num_rows > 0) {
        $customer_data = $result->fetch_assoc();

        // Insert the customer data into the backup table before deletion
        $backup_query = "INSERT INTO backup_customers (id, full_name, address, phone_number, loan_apply_date, loan_amount, interest_rate, status, confirmation_date, no_of_months, due_per_month) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $backup_stmt = $conn->prepare($backup_query);
        $backup_stmt->bind_param("issssdsdssi", 
            $customer_data['id'], 
            $customer_data['full_name'], 
            $customer_data['address'], 
            $customer_data['phone_number'], 
            $customer_data['loan_apply_date'], 
            $customer_data['loan_amount'], 
            $customer_data['interest_rate'], 
            $customer_data['status'], 
            $customer_data['confirmation_date'], 
            $customer_data['no_of_months'], 
            $customer_data['due_per_month']
        );

        if ($backup_stmt->execute()) {
            // Now delete the customer from the customers table
            $delete_query = "DELETE FROM customers WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bind_param("i", $customer_id);

            // Execute the delete query
            if ($delete_stmt->execute()) {
                // Redirect back to the dashboard after deletion
                header('Location: home.php');
                exit();
            } else {
                echo "Error deleting record: " . $conn->error;
            }
        } else {
            echo "Error backing up record: " . $conn->error;
        }
    } else {
        echo "Customer not found.";
    }
} else {
    echo "Invalid request.";
}
?>
