<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php'; // Include the database connection

// Check if 'id' is passed in the URL
if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Fetch the payment details using the 'id'
    $payment_query = "SELECT * FROM payments WHERE id = ?";
    $stmt = $conn->prepare($payment_query);
    $stmt->bind_param("i", $payment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $payment = $result->fetch_assoc();

    if (!$payment) {
        die("Payment not found.");
    }
} else {
    echo "Payment ID not specified.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 50%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f1f1f1;
        }
        .btn-container {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border: none;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            margin: 5px;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .cancel-button {
            background-color: #dc3545;
        }
        .cancel-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h1>View Payment Details</h1>

    <!-- Display Payment Details -->
    <h2>Payment Information</h2>
    <table id="paymentDetails">
        <tr>
            <th>Customer Name</th>
            <td><?php echo htmlspecialchars($payment['customer_name']); ?></td>
        </tr>
        <tr>
            <th>Paid Amount</th>
            <td><?php echo number_format($payment['amount_paid'], 2); ?></td>
        </tr>
        <tr>
            <th>Paid Date</th>
            <td><?php echo htmlspecialchars($payment['paid_date']); ?></td>
        </tr>
        <tr>
            <th>Total Loan Amount</th>
            <td><?php echo number_format($payment['total_loan_amount'], 2); ?></td>
        </tr>
        <tr>
            <th>Mode of Payment</th>
            <td><?php echo htmlspecialchars($payment['mode_of_payment']); ?></td>
        </tr>
        <tr>
            <th>No Of Dues</th>
            <td><?php echo htmlspecialchars($payment['no_of_due']); ?></td>
        </tr>
        <tr>
            <th>Dues paid</th>
            <td><?php echo htmlspecialchars($payment['dues_paid']); ?></td>
        </tr>
        <tr>
            <th>Remaining due</th>
            <td><?php echo htmlspecialchars($payment['remaining_due']); ?></td>
        </tr>
    </table>

    <div class="btn-container">
        <a href="paid_details.php">
            <button class="button cancel-button">Back to Payment List</button>
        </a>
        <button class="button" onclick="downloadPDF()">Download as PDF</button>
    </div>

    <!-- Download as PDF Function -->
    <script>
        function downloadPDF() {
            window.location.href = "download_pdf.php?id=<?php echo $payment['id']; ?>";
        }
    </script>
</body>
</html>
