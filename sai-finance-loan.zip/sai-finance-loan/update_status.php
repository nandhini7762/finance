<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

// Get the customer ID and new status from the form submission
$customer_id = $_POST['customer_id'];
$status = $_POST['status'];

// Update the status in the database
$stmt = $conn->prepare("UPDATE customers SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $customer_id);
$stmt->execute();

// Redirect back to the customer profile with success message
header('Location: view_customer.php?id=' . $customer_id . '&status_update=success');
exit();
?>
