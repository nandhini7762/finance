<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['username'] === 'admin' && $_POST['password'] === 'admin') {
        $_SESSION['admin'] = true;
        header('Location: home.php');
        exit();
    } else {
        $error = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login - Sai Finance</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        /* Wrapper for the blurred background */
        .background-container {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('loan.png') no-repeat center center fixed;
            background-size: cover;
            filter: blur(8px); /* Apply blur effect to the background */
            z-index: -1; /* Ensure the background is behind the form */
        }

        /* Overlay for the blur effect */
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4); /* Optional overlay to darken the background */
            z-index: -1; /* Ensure overlay is behind the form */
        }

        /* Login Container */
        .login-container {
            background: rgba(255, 255, 255, 0.8); /* Transparent background */
            padding: 40px;
            width: 100%;
            max-width: 500px;
            border-radius: 20px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
            animation: slideIn 1s ease-out;
            z-index: 1; /* Ensure the form is above the overlay */
        }

        /* Logo */
        .logo {
            width: 100px;
            height: 100px;
            margin-bottom: 15px;
            border-radius: 50%;
            border: 3px solid #2a5daa;
            animation: fadeIn 1s ease-in-out;
        }

        /* Heading */
        h1 {
            font-size: 36px;
            color: #2a5daa;
            margin-bottom: 10px;
            animation: fadeIn 1.5s ease-in-out;
        }

        /* Welcome Message */
        p.welcome {
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
        }

        /* Form Styles */
        form input {
            width: 90%;
            padding: 10px;
            margin: 15px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: inset 2px 2px 5px rgba(0, 0, 0, 0.1);
        }

        form button {
            width: 90%;
            padding: 10px;
            font-size: 16px;
            background: blue;
            color: #fff;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        form button:hover {
            background: lightblue;
        }

        /* Error Message */
        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        /* Animations */
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateY(50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- Background container with blur effect -->
    <div class="background-container"></div>
    <!-- Optional overlay to darken the background -->
    <div class="overlay"></div>

    <!-- Login form -->
    <div class="login-container">
        <!-- Logo -->
        <img src="logooo.jpg" alt="Sai Finance Logo" class="logo">
        <h1>Sai Finance</h1>
        <p class="welcome">Welcome! Log in as a Loan Officer to access the admin dashboard.</p>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <br>
            <button type="submit">Login</button>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        </form>
    </div>
</body>
</html>
