<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $loan_amount = $_POST['loan_amount'];
    $interest_rate = $_POST['interest_rate'];
    $no_of_months = $_POST['no_of_months'];
    $due_per_month = round((($loan_amount * $interest_rate / 100 * $no_of_months) / 12) + ($loan_amount / $no_of_months));

    $stmt = $conn->prepare("INSERT INTO customers (full_name, address, phone_number, alt_number, loan_apply_date, loan_amount, interest_rate, confirmation_date, no_of_months, due_per_month) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssii", $_POST['full_name'], $_POST['address'], $_POST['phone_number'], $_POST['alt_number'], $_POST['loan_apply_date'], $_POST['loan_amount'], $_POST['interest_rate'], $_POST['confirmation_date'], $_POST['no_of_months'], $due_per_month);
    $stmt->execute();

    $customer_id = $stmt->insert_id;

    header('Location: view_customer.php?id=' . $customer_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .form-container {
            width: 40%;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        form label {
            font-size: 1rem;
            font-weight: bold;
        }
        form label.required::after {
            content: " *";
            color: red;
        }
        form input {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form input[readonly] {
            background-color: #e9e9e9;
            color: #555;
        }
        form button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form button[type="submit"] {
            background-color: #4CAF50;
            color: white;
        }
        form button[type="button"] {
            background-color: #f44336;
            color: white;
        }
    </style>
    <script>
        function calculateDueAmount() {
            var loanAmount = parseFloat(document.getElementById('loan_amount').value) || 0;
            var interestRate = parseFloat(document.getElementById('interest_rate').value) || 0;
            var noOfMonths = parseInt(document.getElementById('no_of_months').value) || 0;

            var dueAmount = Math.round(((loanAmount * interestRate / 100 * noOfMonths) / 12) + (loanAmount / noOfMonths));
            document.getElementById('due_per_month').value = dueAmount;
        }

        function restrictInput(event, type) {
            var key = event.key;
            var regex;

            switch(type) {
                case 'full_name':
                    regex = /^[A-Za-z\s]+$/;
                    break;
                case 'phone_number':
                case 'alt_number':
                    regex = /^[0-9]+$/;
                    break;
                case 'loan_amount':
                case 'interest_rate':
                case 'no_of_months':
                    regex = /^[0-9.]+$/;
                    break;
                default:
                    return;
            }

            if (!regex.test(key) && key !== 'Backspace') {
                event.preventDefault();
            }
        }

        function validatePhoneNumber(input) {
            let phoneNumber = input.value;

            if (phoneNumber.length === 10) {
                if (/^(\d)\1{9}$/.test(phoneNumber)) {
                    alert("Phone number cannot have all the same digits.");
                    input.setCustomValidity("Phone number cannot have all the same digits.");
                } else {
                    input.setCustomValidity("");
                }
            } else {
                input.setCustomValidity("");
            }
        }

        window.onload = function() {
            document.getElementById('loan_amount').addEventListener('input', calculateDueAmount);
            document.getElementById('interest_rate').addEventListener('input', calculateDueAmount);
            document.getElementById('no_of_months').addEventListener('input', calculateDueAmount);
        };
    </script>
</head>
<body>
    <div class="form-container">
        <form method="POST">
            <label for="full_name" class="required">Full Name</label>
            <input type="text" name="full_name" id="full_name" placeholder="Full Name" required onkeydown="restrictInput(event, 'full_name')" autocomplete="off">
            
            <label for="address" class="required">Address</label>
            <input type="text" name="address" id="address" placeholder="Address" required autocomplete="off">
            
            <label for="phone_number" class="required">Phone Number</label>
            <input type="text" name="phone_number" id="phone_number" placeholder="Phone Number" required oninput="validatePhoneNumber(this)" onkeydown="restrictInput(event, 'phone_number')" maxlength="10" autocomplete="off">
            
            <label for="alt_number">Alternative Number</label>
            <input type="text" name="alt_number" id="alt_number" placeholder="Alternative Number" oninput="validatePhoneNumber(this)" onkeydown="restrictInput(event, 'alt_number')" maxlength="10" autocomplete="off">
            
            <label for="loan_apply_date" class="required">Loan Apply Date</label>
            <input type="date" name="loan_apply_date" id="loan_apply_date" required>
            
            <label for="loan_amount" class="required">Loan Amount</label>
            <input type="text" name="loan_amount" id="loan_amount" placeholder="Loan Amount" required onkeydown="restrictInput(event, 'loan_amount')" autocomplete="off">
            
            <label for="interest_rate" class="required">Interest Rate (%)</label>
            <input type="text" name="interest_rate" id="interest_rate" placeholder="Interest Rate" required onkeydown="restrictInput(event, 'interest_rate')" autocomplete="off">
            
            <label for="confirmation_date" class="required">Confirmation Date</label>
            <input type="date" name="confirmation_date" id="confirmation_date" required>
            
            <label for="no_of_months" class="required">Number of Months</label>
            <input type="text" name="no_of_months" id="no_of_months" placeholder="Number of Months" required onkeydown="restrictInput(event, 'no_of_months')" autocomplete="off">
            
            <label for="due_per_month" class="required">Due Per Month</label>
            <input type="text" name="due_per_month" id="due_per_month" placeholder="Due Per Month" readonly>
            
            <button type="submit">Submit</button>
            <button type="button" onclick="window.location.href='home.php'">Cancel</button>
        </form>
    </div>
</body>
</html>
