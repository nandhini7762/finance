<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include 'db.php';

if (isset($_GET['id'])) {
    $backup_id = $_GET['id'];

    // Fetch the backup record from the backup_customers table
    $backup_query = "SELECT * FROM backup_customers WHERE id = ?";
    $stmt = $conn->prepare($backup_query);
    $stmt->bind_param("i", $backup_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $backup = $result->fetch_assoc();

        // Insert the data into the main customers table
        $insert_query = "INSERT INTO customers (full_name, address, phone_number, loan_apply_date, loan_amount, interest_rate, status, confirmation_date, no_of_months, due_per_month)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssssdiisii", $backup['full_name'], $backup['address'], $backup['phone_number'], $backup['loan_apply_date'], $backup['loan_amount'], $backup['interest_rate'], $backup['status'], $backup['confirmation_date'], $backup['no_of_months'], $backup['due_per_month']);
        $stmt->execute();

        // After inserting into the main table, delete the backup record
        $delete_query = "DELETE FROM backup_customers WHERE id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $backup_id);
        $stmt->execute();

        // Redirect to the backup page after restoring and deleting the backup record
        header('Location: backup.php');
        exit();
    } else {
        die("Backup not found.");
    }
}
?>
