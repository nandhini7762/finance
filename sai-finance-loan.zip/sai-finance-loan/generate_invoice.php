<?php
require('fpdf.php');
include 'db.php';

// Get the customer ID from the URL
$customer_id = $_GET['id'];

// Fetch customer details
$stmt = $conn->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

// Initialize FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Add logo at the top center
$pdf->Image('logooo.jpg', 80, 10, 50); // Adjust the x, y, and width values as needed
$pdf->Ln(50); // Increase space below the image (previously 30)

// Title
$pdf->Cell(0, 10, 'Loan Invoice', 0, 1, 'C');
$pdf->Ln(10);

// Customer Details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(50, 10, 'Full Name:', 0, 0);
$pdf->Cell(0, 10, $customer['full_name'], 0, 1);

$pdf->Cell(50, 10, 'Address:', 0, 0);
$pdf->MultiCell(0, 10, $customer['address']);

$pdf->Cell(50, 10, 'Phone Number:', 0, 0);
$pdf->Cell(0, 10, $customer['phone_number'], 0, 1);

$pdf->Cell(50, 10, 'Alternative Number:', 0, 0);
$pdf->Cell(0, 10, $customer['alt_number'], 0, 1);

$pdf->Cell(50, 10, 'Loan Apply Date:', 0, 0);
$pdf->Cell(0, 10, $customer['loan_apply_date'], 0, 1);

$pdf->Cell(50, 10, 'Loan Amount:', 0, 0);
$pdf->Cell(0, 10, $customer['loan_amount'], 0, 1);

$pdf->Cell(50, 10, 'Interest Rate:', 0, 0);
$pdf->Cell(0, 10, $customer['interest_rate'] . '%', 0, 1);

$pdf->Cell(50, 10, 'No of Months:', 0, 0);
$pdf->Cell(0, 10, $customer['no_of_months'], 0, 1);

$pdf->Cell(50, 10, 'Due Per Month:', 0, 0);
$pdf->Cell(0, 10, $customer['due_per_month'], 0, 1);

$pdf->Cell(50, 10, 'Status:', 0, 0);
$pdf->Cell(0, 10, $customer['status'], 0, 1);

$pdf->Ln(10);
$pdf->Cell(0, 10, 'Thank you for doing business with us.', 0, 1, 'C');

// Output PDF
$pdf->Output('D', 'Invoice_' . str_replace(' ', '_', $customer['full_name']) . '.pdf');
?>
